import React, { useEffect, useState, useRef } from 'react'
import songsData from './songs'

const FAV_KEY = 'rt_favs_v1'
const PL_KEY  = 'rt_pl_v1'

function SongCard({song, isFav, onFav, onAdd, onPlay}) {
  return (
    <article className="card">
      <img src={song.cover} alt={song.title} className="cover" />
      <div className="body">
        <div className="title">{song.title}</div>
        <div className="meta">Artist: <b>{song.artist}</b></div>
        <div className="meta">Genre: <span className="tag">{song.genre}</span></div>
      </div>
      <div className="actions">
        <button className="btn primary" onClick={() => onPlay(song.src)}>Play</button>
        <button className="btn ghost" onClick={() => onAdd(song.id)}>Add to Playlist</button>
        <button className="btn ghost" onClick={() => onFav(song.id)}>
          {isFav ? '♥ Favorite' : '♡ Favorite'}
        </button>
      </div>
      <div style={{padding:'10px'}}>
        <audio controls preload="none" src={song.src}></audio>
      </div>
    </article>
  )
}

export default function App(){
  const [query, setQuery] = useState('')
  const [favs, setFavs] = useState(() => JSON.parse(localStorage.getItem(FAV_KEY)) || [])
  const [playlist, setPlaylist] = useState(() => JSON.parse(localStorage.getItem(PL_KEY)) || [])
  const audioRef = useRef(new Audio())

  useEffect(() => { localStorage.setItem(FAV_KEY, JSON.stringify(favs)) }, [favs])
  useEffect(() => { localStorage.setItem(PL_KEY, JSON.stringify(playlist)) }, [playlist])

  function toggleFav(id){
    setFavs(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id])
  }
  function addToPlaylist(id){
    setPlaylist(prev => [...prev, id])
  }
  function removeFromPlaylist(index){
    setPlaylist(prev => prev.filter((_,i) => i !== index))
  }
  function playSrc(src){
    const audio = audioRef.current
    if(!src) return
    if(audio.src !== new URL(src, location).href) audio.src = src
    audio.play()
  }

  const filtered = songsData.filter(s => {
    const q = query.trim().toLowerCase()
    if(!q) return true
    return s.title.toLowerCase().includes(q) || s.artist.toLowerCase().includes(q)
  })

  return (
    <div className="app">
      <aside className="sidebar">
        <h2>🎵 Rhythmic Tunes</h2>
        <nav>
          <a href="#home">Home</a>
          <a href="#favs">Favorites</a>
          <a href="#pl">Playlist</a>
        </nav>
      </aside>

      <main className="main">
        <header className="top">
          <h1>Songs</h1>
          <input placeholder="Search by title or artist" value={query} onChange={e => setQuery(e.target.value)} />
        </header>

        <section id="home">
          <div className="grid">
            {filtered.map(s => (
              <SongCard
                key={s.id}
                song={s}
                isFav={favs.includes(s.id)}
                onFav={() => toggleFav(s.id)}
                onAdd={() => addToPlaylist(s.id)}
                onPlay={(src) => playSrc(src)}
              />
            ))}
          </div>
        </section>

        <section id="favs">
          <h2>Favorites</h2>
          <div className="grid">
            {songsData.filter(s => favs.includes(s.id)).map(s => (
              <SongCard key={s.id} song={s} isFav={true} onFav={() => toggleFav(s.id)} onAdd={() => addToPlaylist(s.id)} onPlay={src => playSrc(src)} />
            ))}
            {favs.length === 0 && <p className="muted">No favorites yet — add from Home ❤️</p>}
          </div>
        </section>

        <section id="pl">
          <h2>Playlist</h2>
          <table className="pl-table">
            <thead><tr><th>#</th><th>Title</th><th>Artist</th><th>Genre</th><th>Player</th><th>Action</th></tr></thead>
            <tbody>
              {playlist.length === 0 && <tr><td colSpan="6" className="muted">Playlist empty — add songs.</td></tr>}
              {playlist.map((id, idx) => {
                const s = songsData.find(x => x.id === id)
                return s ? (
                  <tr key={idx}>
                    <td>{idx+1}</td>
                    <td>{s.title}</td>
                    <td>{s.artist}</td>
                    <td>{s.genre}</td>
                    <td><audio controls src={s.src}></audio></td>
                    <td><button className="btn danger" onClick={() => removeFromPlaylist(idx)}>Remove</button></td>
                  </tr>
                ) : null
              })}
            </tbody>
          </table>
        </section>
      </main>
    </div>
  )
}