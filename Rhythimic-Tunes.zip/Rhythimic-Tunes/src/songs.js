const songsData = [
  {
    id: 'iwanna',
    title: 'I Wanna Be Yours',
    artist: 'Arctic Monkeys',
    genre: 'Indie rock pop',
    cover: '/images/i_wanna_be_yours.jpeg',
    src: '/songs/i_wanna_be_yours.mp3'
  },
  {
    id: 'aaruyire',
    title: 'Aaruyire',
    artist: 'A.R.Rahman, Chinmayi',
    genre: 'Kollywood',
    cover: '/images/aaruyire.jpeg',
    src: '/songs/aaruyire.mp3'
  },
  {
    id: 'perfect',
    title: 'Perfect',
    artist: 'Ed Sheeran',
    genre: 'Soft Rock',
    cover: '/images/perfect.jpeg',
    src: '/songs/perfect.mp3'
  },
  {
    id: 'moral',
    title: 'Moral of the Story',
    artist: 'Ashe',
    genre: 'Indie Pop',
    cover: '/images/moral_of_the_story.jpeg',
    src: '/songs/moral_of_the_story.mp3'
  }
]

export default songsData